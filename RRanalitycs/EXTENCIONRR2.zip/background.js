// background.js - AGENTE RYR V26.0 (OMNI-FAILOVER ENFORCED)
let SERVER_URL = "http://10.21.41.168:18791"; // Canal Virtual Primario (ZeroTier)

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const ruteo = {
        "login_operador": "/api/auth/login",
        "sincronizar_avatar_automatico": "/api/sincronizar_avatar_automatico",
        "solicitar_traduccion": "/api/traducir",
        "sincronizar_perfil_masivo": "/api/sincronizar_perfil",
        "sync_historial_completo": "/api/sync_historial",
        "live_stream": "/api/live-stream",            // Nuevo Endpoint Optimizado
        "registrar_infraccion": "/api/telemetry/errors" // Nuevo Endpoint de Auditoría
    };

    if (ruteo[request.accion]) {
        // Enfoque agresivo: fetch con límite de respuesta rápida para evitar congelamientos
        fetch(`${SERVER_URL}${ruteo[request.accion]}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(request.payload || request)
        })
        .then(r => r.json())
        .then(data => sendResponse(data))
        .catch(err => {
            console.log("⚠️ Red ZeroTier saturada o bloqueada por Windows. Conmutando a Red Local LAN...");
            const alternativa = SERVER_URL.includes("10.21.41.168") ? "http://192.168.1.61:18791" : "http://10.21.41.168:18791";
            
            fetch(`${alternativa}${ruteo[request.accion]}`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(request.payload || request)
            })
            .then(r2 => r2.json())
            .then(data2 => {
                SERVER_URL = alternativa;
                console.log("🚀 Enrutamiento Titan reajustado con éxito hacia:", alternativa);
                sendResponse(data2);
            })
            .catch(err2 => {
                sendResponse({ success: false, espanol: "Error total: Verifica la IP física en Putty ejecutando 'ip a' o habilita 'Global IPs' en ZeroTier." });
            });
        });
        return true; 
    }

    if (request.accion === "verificar_estado") {
        fetch(`${SERVER_URL}/api/estado_perfil/${request.cliente_id}`)
        .then(r => r.json()).then(data => sendResponse(data))
        .catch(err => {
            const alternativa = SERVER_URL.includes("10.21.41.168") ? "http://192.168.1.61:18791" : "http://10.21.41.168:18791";
            fetch(`${alternativa}/api/estado_perfil/${request.cliente_id}`)
            .then(r2 => r2.json()).then(data2 => { SERVER_URL = alternativa; sendResponse(data2); })
            .catch(() => sendResponse({ actualizado: false }));
        });
        return true;
    }
});