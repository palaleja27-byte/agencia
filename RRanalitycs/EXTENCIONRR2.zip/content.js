chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "unlock_terminal") {
        // Buscar el overlay inyectado que bloquea la terminal del operador
        const overlay = document.getElementById('ryr-lock-overlay');
        if (overlay) {
            overlay.remove(); // Remueve la capa negra y libera la interfaz
            console.log(`[TITAN] Terminal liberada para el ${request.role}: ${request.username}`);
        }
    }
});