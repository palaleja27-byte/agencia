console.log("🚀 [TITAN] ¡Popup.js ha sido cargado en el navegador!");

// CONFIGURACIÓN: IP local real de tu servidor Ubuntu activa en este momento
const SERVER_URL = "https://a660cb437e08c6.lhr.life";;

document.addEventListener("DOMContentLoaded", () => {
    console.log("[TITAN] DOM completamente cargado. Iniciando mapeo de la interfaz...");

    // 1. RASTREADOR INTELIGENTE DEL BOTÓN (Por ID o por el texto visible)
    let executeBtn = document.getElementById("executeBtn");
    if (!executeBtn) {
        const buttons = document.getElementsByTagName("button");
        for (let btn of buttons) {
            if (btn.innerText.toUpperCase().includes("EJECUTAR ACCIÓN")) {
                executeBtn = btn;
                console.log("[TITAN] Botón detectado exitosamente por texto: 'EJECUTAR ACCIÓN'.");
                break;
            }
        }
    }

    // 2. RASTREADOR INTELIGENTE DE INPUTS (Por ID o por tipo de campo)
    const usernameInput = document.getElementById("username") || document.querySelector("input[type='text']");
    const passwordInput = document.getElementById("password") || document.querySelector("input[type='password']");
    const roleSelect = document.getElementById("role") || document.querySelector("select");
    
    // 3. RASTREADOR O CREACIÓN DE CONTENEDOR DE ESTADO
    let statusMessage = document.getElementById("statusMessage");
    if (!statusMessage && executeBtn) {
        statusMessage = document.createElement("div");
        statusMessage.id = "statusMessage";
        statusMessage.style.textAlign = "center";
        statusMessage.style.marginTop = "12px";
        statusMessage.style.fontWeight = "bold";
        executeBtn.parentNode.appendChild(statusMessage);
        console.log("[TITAN] Contenedor de estados creado dinámicamente.");
    }

    if (!executeBtn) {
        console.error("❌ [TITAN] CRÍTICO: No se encontró el botón 'EJECUTAR ACCIÓN'. Verifica tu popup.html.");
        return;
    }

    console.log("[TITAN] Todos los componentes listos. Esperando clic...");

    // 4. CAPTURA DEL EVENTO CLIC
    executeBtn.addEventListener("click", async () => {
        console.log("⚡ [TITAN] ¡Clic detectado en el botón EJECUTAR ACCIÓN!");
        
        const username = usernameInput ? usernameInput.value.trim() : "";
        const password = passwordInput ? passwordInput.value.trim() : "";
        const role = roleSelect ? roleSelect.value : "";

        console.log(`[TITAN] Datos capturados -> Usuario: ${username} | Rol: ${role}`);

        if (!username || !password) {
            updateStatus("🚨 Error: Ingresa usuario y contraseña.", "error");
            return;
        }

        updateStatus("⚡ Conectando con servidor TITAN...", "loading");

        // 5. ENVÍO DE DATOS AL BACKEND FLASK
        try {
            console.log(`[TITAN] Despachando POST Request hacia: ${SERVER_URL}/api/login`);
            
            const response = await fetch(`${SERVER_URL}/api/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username: username,
                    password: password,
                    role: role
                })
            });

            console.log(`[TITAN] Respuesta recibida de Flask. Status Code: ${response.status}`);
            const data = await response.json();
            console.log("[TITAN] Cuerpo de la respuesta mapeado:", data);

            if (response.ok && (data.ok || data.success)) {
                updateStatus("🟢 ¡Conexión exitosa! Agente activo.", "success");
                
                // 6. DISPARAR EXTRACCIÓN AL CONTENT SCRIPT
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (tabs[0] && tabs[0].id) {
                        console.log("[TITAN] Inyectando orden de extracción en la pestaña activa...");
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: "init_extraction",
                            user: username,
                            role: role,
                            server: SERVER_URL
                        }, (res) => {
                            if (chrome.runtime.lastError) {
                                console.warn("[TITAN] Advertencia: Content script no detectado en esta pestaña.");
                            } else {
                                console.log("[TITAN] Content script ejecutando extracción con éxito:", res);
                            }
                        });
                    }
                });

            } else {
                updateStatus(`❌ Denegado: ${data.message || "Credenciales incorrectas."}`, "error");
            }

        } catch (error) {
            console.error("❌ [TITAN] Error de red o bloqueo de seguridad:", error);
            updateStatus("🚨 Error: El servidor no responde o bloqueó la IP.", "error");
        }
    });

    function updateStatus(text, type) {
        statusMessage.innerText = text;
        if (type === "error") {
            statusMessage.style.color = "#ff4d4d"; // Rojo alerta
        } else if (type === "success") {
            statusMessage.style.color = "#00ffcc"; // Cian Cyberpunk exitoso
        } else {
            statusMessage.style.color = "#ffcc00"; // Amarillo cargando
        }
    }
});